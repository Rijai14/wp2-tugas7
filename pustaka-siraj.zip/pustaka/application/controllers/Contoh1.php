<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h1>Perkenalkan</h1>";
        echo"Nama Saya Siraj Rabbani
            Saya tinggal di daerah Bekasi
            olah raga yang saya sukai adalah
            Voli dan Basket";
    }
}